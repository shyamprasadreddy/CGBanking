package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;

public class BankingServicesImpl implements BankingServices {
	private BankingDAOServicesImpl daoservices=new BankingDAOServicesImpl();
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {

		return daoservices.insertCustomer(new Customer(firstName, lastName, emailId, panCard,new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));		
	}

	@Override
	public long openAccount(int customerId, String accountType, float accountBalance) {
		return daoservices.insertAccount(customerId, new Account(accountType, accountBalance));

	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {

		return daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {
		if(amount>0&&amount<getAccountDetails(customerId, accountNo).getAccountBalance()&&daoservices.getAccount(customerId, accountNo).getPinNumber()==pinNumber){
			getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
			return daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
			}
		else
			return -1;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
		
		if(customerIdFrom==customerIdTo&&accountNoFrom==accountNoTo){
			System.out.println("cannot send to same account");
		}
		else if(transferAmount<getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance()){
			getAccountDetails(customerIdTo, accountNoTo).setAccountBalance(getAccountDetails(customerIdTo, accountNoTo).getAccountBalance()+transferAmount);
			getAccountDetails(customerIdFrom, accountNoFrom).setAccountBalance(getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance()-transferAmount);
	
		}
		else if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)==-1){
			System.out.println("unable to withdraw");
		}
			return true;
		
	}

	@Override
	public Customer getCustomerDetails(int customerId) {

		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {

		return daoservices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
		Account account=daoservices.getAccount(customerId, accountNo);
		return daoservices.generatePin(customerId, account);
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {

		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() {

		return daoservices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {

		return daoservices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {

		return null;
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {

		return null;
	}

}
